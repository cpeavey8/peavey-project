from bson import ObjectId
import pymongo
from pydantic import BaseModel
from .user_models import User, UserCollection, UserQuery, UserUpdate

# Cooper Peavey
# CS 518 - DB Manager
class DBManager:
    
    def to_obj_id(self, id_str):
        try:
            oid = ObjectId(id_str)
            return oid
        except Exception as e:
            return None

    def __init__(self, conn_str:str, db, col):
        '''connect to db server and set self.col'''
        
        myclient = pymongo.MongoClient(conn_str)
        mydb = myclient[db]
        self.col = mydb[col]

    def create(self, d: dict):
        '''create user and return inserted_id'''
        result = self.col.insert_one(d)
        return str(result.inserted_id)
    

    def read_by_id(self, obj_id:str):
        '''read by id and return one'''
        oid = self.to_obj_id(obj_id)
        if not oid:
            return None
        doc = self.col.find_one({'_id': oid})
        return self.normalize(doc)

        
    def read(self,query:dict):
        '''read by query and return many'''

        query = {k: v for k, v in query.items() if v is not None}
        if 'id' in query:
            oid = ObjectId(query['id'])
            query['_id'] = oid
            del query['id']

        docs = list(self.col.find(query))
        return [self.normalize(d) for d in docs]
    
    def read_all(self):
        '''read all and return many'''

        return [self.normalize(d) for d in self.col.find({})]

    def update(self,obj_id,updates:dict):
        ''' update by id and return modified_count '''

        oid = self.to_obj_id(obj_id)
        if not oid:
            return 0
        return self.col.update_one({'_id': oid}, {'$set': updates}).modified_count
        
    def update_by_query(self,query:dict,updates:dict):
        ''' update by query and return modified_count '''
        q = {k: v for k, v in query.items() if v is not None}
        if 'id' in q:
            oid = self.to_obj_id(q['id'])
            if not oid:
                return 0
            q['_id'] = oid
            del q['id']
        return self.col.update_many(q, {'$set': updates}).modified_count

    def delete_by_id(self,obj_id):
        ''' delete by id and return deleted_count '''

        oid = self.to_obj_id(obj_id)
        if not oid:
            return 0
        result = self.col.delete_one({'_id': oid})
        return result.deleted_count
    
    def delete(self,query:dict):
        ''' update by query and return deleted_count '''

        query = {k: v for k, v in query.items() if v is not None}
        if 'id' in query:
            oid = self.to_obj_id(query['id'])
            if not oid:
                return 0
            query['_id'] = oid
            del query['id']
        result = self.col.delete_many(query)
        return result.deleted_count
    
    def delete_all(self):
        result = self.col.delete_many({})
        return result.deleted_count              

    def normalize(self, doc):
        """Normalize MongoDB document by converting _id to string id"""
        if not doc:
            return None
        if '_id' in doc:
            doc['id'] = str(doc['_id'])
            del doc['_id']
        return doc
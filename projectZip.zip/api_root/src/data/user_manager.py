from data.db_manager import DBManager
from data.user_models import *
import bcrypt

# from pymongo.errors import DuplicateKeyError

class UserManager:
    '''The UserManager takes model objects from the UserAPI.  It dumps them and passes them to DBManager for db operations.
    DBManager returns python objects (e.g. dicts, lists).
    UserManager converts those to model objects and passes back to the UserAPI.
    '''

    #------------------ init and reset ----------

    def __init__(self, dbm: DBManager):
        '''connect to db server and set self.col'''

        self.dbm = dbm
        

    def delete_all(self):
        ''' delete all users except admin (for testing)'''

        count = self.dbm.delete({'username': {'$ne': 'admin'}})
        return count    
    
    #----------------- CRUD ----------------------

    def create(self,user:User) -> str:
        ''' create user
        :returns: id as str'''

        ud = user.model_dump()
        # Hash the password before storing
        if 'password' in ud:
            ud['password'] = bcrypt.hashpw(
                ud['password'].encode('utf-8'), 
                bcrypt.gensalt()
            ).decode('utf-8')
        return self.dbm.create(ud)
    
    def read(self,query:dict) -> User | None:
        ''' read user by query
        :returns: User or None'''
        ud = self.dbm.read(query)
        if not ud:
            return None
        user = User.model_validate(ud[0])
        return user

    def read_all(self) -> UserCollection:
        ''' read users '''
        uds = self.dbm.read_all()
        return [User.model_validate(ud) for ud in uds]

    def read_by_id(self,id: str) -> User:
        ''' read by id
        :returns: User or None'''
        ud = self.dbm.read_by_id(id)
        if not ud:
            return None
        return User.model_validate(ud)



    def read_by_username(self,username: str) -> User | None:
        '''read by username
        :returns: User or None'''
        return self.read({'username': username})


    def update(self,id,q:UserUpdate) -> int:
        '''update user
        :returns: modified_count'''
        update_data = q.model_dump(exclude_unset=True)
        # Hash password if it's being updated
        if 'password' in update_data:
            update_data['password'] = bcrypt.hashpw(
                update_data['password'].encode('utf-8'), 
                bcrypt.gensalt()
            ).decode('utf-8')
        if isinstance(id, dict):
            return self.dbm.update_by_query(id, update_data)
        else:
            return self.dbm.update(id, update_data)
        
    def delete(self,q: UserQuery) -> int:
        '''delete user
        :returns: deleted_count'''
        if isinstance(q, dict):
            query = {k: v for k, v in q.items() if v is not None}
        else:
            query = q.model_dump(exclude_unset=True)
        return self.dbm.delete(query)
    
    
    def authenticate(self,username:str,password:str) -> User | None:
        ''' authenticate user
        :returns: User if authenticated else None'''
        uds = self.dbm.read({'username': username})
        if not uds:
            return None
        ud = uds[0] if isinstance(uds, list) else uds
        hashed = ud.get('password')
        if not hashed:
            return None
        # Ensure hashed is bytes for bcrypt.checkpw
        try:
            hashed_bytes = hashed.encode('utf-8') if isinstance(hashed, str) else hashed
            if not bcrypt.checkpw(password.encode('utf-8'), hashed_bytes):
                return None
        except Exception:
            return None
        return User.model_validate(ud)
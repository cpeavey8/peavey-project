# from accounts.data.user_api import UserAPI
# um = UserAPI()

'''
Works statically - UserLogin.setup_db, UserLogin.get
But also used to create instances of users for login purposes (current_user)
'''
from flask import current_app
from flask_login import UserMixin


class UserLogin(UserMixin):

    def __init__(self,user_id,username, admin=None):
        self.id = str(user_id)
        self.username = username
        self.admin = bool(admin)

    @staticmethod
    def setup_db(um):
        UserLogin.um = um

    @staticmethod
    def get(user_id):
        ''' get user by id; construct and return User object
        use current_app.um to access UserAPI / UserManager'''

        print(f"Looking up user with ID: {user_id}")
        u = current_app.um.read_by_id(str(user_id))
        print(f"Found user data: {u}")

        if u:
            # Handle both id and _id fields
            uid = u.get('id') or u.get('_id')
            un = u.get('username')
            admin = u.get('admin', False)

            print(f"Creating UserLogin with id={uid}, username={un}, admin={admin}")
            return UserLogin(uid, un, admin)
        return None

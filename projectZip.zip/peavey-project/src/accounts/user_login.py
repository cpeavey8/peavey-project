'''
Works statically - UserLogin.setup_db, UserLogin.get
But also used to create instances of users for login purposes (current_user)
'''
from flask import current_app
from flask_login import UserMixin


class UserLogin(UserMixin):

    def __init__(self,user_id,username, admin=None):
        self.id = str(user_id)
        self.username = username
        self.admin = bool(admin)

    @staticmethod
    def setup_db(um):
        UserLogin.um = um

    @staticmethod
    def get(user_id):
        ''' get user by id; construct and return User object
        use current_app.um to access UserAPI / UserManager'''

        current_app.logger.info(f"Looking up user with ID: {user_id}")
        um = current_app.um
        u = um.read_by_id(user_id)
        current_app.logger.info(f"Found user data: {u}")

        if u:
            uid = u.get('id') or u.get('_id')
            un = u.get('username')
            admin = u.get('admin', False)

            current_app.logger.info(f"Creating UserLogin with id={uid}, username={un}, admin={admin}")
            return UserLogin(uid, un, admin)
        
        current_app.logger.warning(f"No user found for ID: {user_id} - this may indicate a stale session")
        return None

from .user_manager import UserManager
from .user_models import *
from bson import ObjectId

class UserAPI:

    def __init__(self,user_manager:UserManager):
        self.um = user_manager

    def authenticate(self, username, password):
        return self.um.authenticate(username, password)

    def delete_all(self ) -> int:
        return self.um.delete_all()

    def create(self, user: dict ) -> str:
        '''takes an unvalidated dict, validates, and passes dict to UserManager for insertion'''

        u = User(**user).model_dump()
        return self.um.create(u)

    def read_by_id(self, uid: str ) -> dict:
        '''reads, validates, and returns dict'''
        u = self.um.read_by_id(uid)
        if u:
            # Ensure all ObjectId values are converted to strings
            for k, v in list(u.items()):
                if isinstance(v, ObjectId):
                    u[k] = str(v)
            if 'id' not in u and '_id' in u:
                u['id'] = str(u['_id'])
            return User(**u).model_dump()
    
    def read_all(self) -> dict:

        us = self.um.read_all()
        # Normalize any ObjectId instances in returned documents
        normalized = []
        for u in us:
            nu = {}
            for k, v in u.items():
                if isinstance(v, ObjectId):
                    nu[k] = str(v)
                else:
                    nu[k] = v
            if 'id' not in nu and '_id' in nu:
                nu['id'] = str(nu['_id'])
            normalized.append(nu)
        return UserCollection(users=normalized).model_dump()
    
    def read(self, query: dict ) -> dict:

        q = UserQuery(**query)
        us = self.um.read(q.model_dump())
        normalized = []
        for u in us:
            nu = {}
            for k, v in u.items():
                # Failsafe: convert ObjectId to string for all fields
                if isinstance(v, ObjectId):
                    nu[k] = str(v)
                else:
                    nu[k] = v
            # Ensure both 'id' and '_id' are strings
            if '_id' in nu:
                nu['_id'] = str(nu['_id'])
            if 'id' not in nu and '_id' in nu:
                nu['id'] = str(nu['_id'])
            elif 'id' in nu:
                nu['id'] = str(nu['id'])
            normalized.append(nu)
        return UserCollection(users=normalized).model_dump()
    
    def update(self,id:str,update:dict) -> int:

        u = UserUpdate(**update)
        n = self.um.update(id,u.model_dump())
        return n
    
    def delete_by_id(self,id:str) -> int:

        return self.um.delete_by_id(id)

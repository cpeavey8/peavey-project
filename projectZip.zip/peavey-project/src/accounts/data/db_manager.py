from bson import ObjectId
import pymongo
from pydantic import BaseModel
from .user_models import User, UserCollection, UserQuery, UserUpdate

# Cooper Peavey
# CS 518 - DB Manager
class DBManager:

    def __init__(self, conn_str:str, db, col):
        '''connect to db server and set self.col'''
        
        myclient = pymongo.MongoClient(conn_str)
        mydb = myclient[db]
        self.col = mydb[col]

    def create(self, d: dict):
        '''create user and return inserted_id'''
        if not d.get('_id') and not d.get('id'):
            d['_id'] = ObjectId()
        elif d.get('id'):
            d['_id'] = d['id']
            del d['id']
        elif d.get('_id') is None:
            d['_id'] = ObjectId()
        # Always set id field as string version of _id for downstream code
        try:
            d['id'] = str(d['_id'])
        except Exception:
            d['id'] = None
        self.col.insert_one(d)
        return str(d['_id'])
    

    def read_by_id(self, obj_id:str):
        '''read by id and return one'''
        try:
            object_id = ObjectId(obj_id)
            doc = self.col.find_one({
                '$or': [
                    {'_id': object_id},  
                    {'_id': obj_id},    
                    {'id': obj_id}       
                ]
            })
        except:
            doc = self.col.find_one({
                '$or': [
                    {'_id': obj_id},
                    {'id': obj_id}
                ]
            })
        
        if doc:
            if '_id' in doc:
                s = str(doc['_id'])
                # Provide both _id and id as strings for downstream consumers
                doc['_id'] = s
                doc['id'] = s
        return doc

        
    def read(self,query:dict):
        '''read by query and return many'''
        query = {k: v for k, v in query.items() if v is not None}
        docs = list(self.col.find(query))
        for doc in docs:
            if '_id' in doc:
                s = str(doc['_id'])
                # Ensure both fields are present and are strings
                doc['_id'] = s
                doc['id'] = s
        return docs
    
    def read_all(self):
        '''read all and return many'''
        docs = list(self.col.find({}))
        for doc in docs:
            if '_id' in doc:
                s = str(doc['_id'])
                doc['_id'] = s
                doc['id'] = s
        return docs

    def update(self,obj_id,updates:dict):
        ''' update by id and return modified_count '''

        from bson import ObjectId
        try:
            oid = ObjectId(obj_id)
            result = self.col.update_one({'_id': oid}, {'$set': updates})
            if result.modified_count == 0:
                # Try string id fallback
                result = self.col.update_one({'_id': obj_id}, {'$set': updates})
        except Exception:
            result = self.col.update_one({'_id': obj_id}, {'$set': updates})
        return result.modified_count
        

    def delete_by_id(self,obj_id):
        ''' delete by id and return deleted_count '''

        from bson import ObjectId
        try:
            oid = ObjectId(obj_id)
            result = self.col.delete_one({'_id': oid})
            if result.deleted_count == 0:
                result = self.col.delete_one({'_id': obj_id})
        except Exception:
            result = self.col.delete_one({'_id': obj_id})
        return result.deleted_count
    
    def delete(self,query:dict):
        ''' update by query and return deleted_count '''

        result = self.col.delete_many(query)
        return result.deleted_count
    
    def delete_all(self):
        result = self.col.delete_many({})
        return result.deleted_count              
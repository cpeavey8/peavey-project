# Find a Guide

Name: 
Credits:  
    * any notes about collaboration, use of AI, etc.
    * you can collaborate about ideas and even show code, but you shouldn't share code

## Repo structure

repo structure:
* app/
    * accounts/
        * data/
            * user_api.py
            * user_manager.py
            * db_manager.py
            * user_tests.py
        * templates/
            * create.html
            * users.html		
        * routes.py
    * templates/
        * index.html    
    * app.py
    * README.md